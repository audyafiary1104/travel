<?php $__env->startSection('content'); ?>
<div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Master Transaski</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Agent Code</th>
                                            <th>Jumlah Balance</th>    
                                            <th>Bukti pembayaran</th>                                            
                                            <th>Biaya Admin</th>                                            
                                            <th>Pajak</th>                                            
                                            <th>Harga</th>      
                                            <th>action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $balance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($balance->name); ?></td>
                                            <td><?php echo e($balance->jumlah_balance); ?></td>
                                            <td><img src="<?php echo e("/img/bukti_tf/".$balance->bukti_tf); ?>" alt="" width="100"></td>
                                            <td><?php echo e($balance->biaya_admin); ?></td>
                                            <td><?php echo e($balance->pajak); ?></td>
                                            <td><?php echo e($balance->jumlah_ditf); ?> </td>
                                            <td><button type="button" onclick="window.location.href='<?php echo e(route('master_transaksi.payment_confim', [$balance->id, $balance->jumlah_balance])); ?>' "class="btn btn-success">Konfimasi</button>
</td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\trainer\Downloads\travel-master\Modules\ConfirmasiAgent\Providers/../Resources/views/payment.blade.php ENDPATH**/ ?>