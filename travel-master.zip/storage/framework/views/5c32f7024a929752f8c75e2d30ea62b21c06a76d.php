<?php $__env->startSection('content'); ?>

<div class="animated fadeIn">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">My Booking</strong>
                </div>
                <div class="card-header">
                
                                                        </div>
                <div class="card-body">
                    <table id="bootstrap-data-table" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                            <th>Nomor  Booking</th>
                                <th>Nama Hotel</th>
                                <th>Type Room</th>
                                <th>Check in</th>
                                <th>Check out</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td><?php echo e($user->nomor_booking); ?></td>
                                <td><?php echo e($user->nama_hotels); ?></td>
                                <td><?php echo e($user->type_room); ?></td>
                                <td><?php echo e($user->check_in); ?></td>
                                <td><?php echo e($user->check_out); ?></td>
                                <td><?php echo e($user->status); ?></td>
                            </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('agent_dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\trainer\Downloads\travel-master\Modules\AgentDashboard\Providers/../Resources/views/my_booking.blade.php ENDPATH**/ ?>