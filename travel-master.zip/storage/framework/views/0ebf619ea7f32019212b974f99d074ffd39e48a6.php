<?php $__env->startSection('content'); ?>
<div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Master Transaksi Hotels</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Agent Code</th>
                                            <th>Pajak</th>
                                            <th>Nama hotel</th>
                                            <th>Nama Guest</th>
                                            <th>check in </th>
                                            <th>check out</th>
                                            <th>Status</th>
                                            <th>Nomor Booking</th>
                                            <th>total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($transaksi->agent_code); ?></td>
                                            <td><?php echo e($transaksi->tax); ?></td>
                                            <td><?php echo e($transaksi->nama_hotels); ?></td>
                                            <td><?php echo e($transaksi->title); ?> <?php echo e($transaksi->first_name); ?> <?php echo e($transaksi->last_name); ?></td>
                                            <td><?php echo e($transaksi->check_in); ?></td>
                                            <td><?php echo e($transaksi->check_out); ?></td>
                                            <td><?php echo e($transaksi->status); ?></td>
                                            <td><?php echo e($transaksi->nomor_booking); ?></td>
                                            <td><?php echo e($transaksi->price); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\trainer\Downloads\travel-master\Modules\MasterCustommer\Providers/../Resources/views/transaksi.blade.php ENDPATH**/ ?>