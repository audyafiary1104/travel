<?php $__env->startSection('content'); ?>
<aside id="colorlib-hero">
			<div class="flexslider">
				<ul class="slides">
			   	<li style="background-image: url(<?php echo e(asset('asset/images/cover-img-4.jpg')); ?>);">
			   		<div class="overlay"></div>
			   		<div class="container-fluid">
			   			<div class="row">
				   			<div class="col-md-6 col-md-offset-3 col-sm-12 col-xs-12 slider-text">
				   				<div class="slider-text-inner text-center">
				   					<h2>by colorlib.com</h2>
				   					<h1>Hotel Overview</h1>
				   				</div>
				   			</div>
				   		</div>
			   		</div>
			   	</li>
			  	</ul>
		  	</div>
		</aside>

		<div class="colorlib-wrap">
			<div class="container">
				<div class="row">
					<div class="col-md-9">
						<div class="row">
							<div class="col-md-12">
								<div class="wrap-division">
                                
									<div class="col-md-12 col-md-offset-0 heading2 animate-box">
										<h2>Select Rooms</h2>
									</div>
									<div class="row">
                                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    										<div class="col-md-12 animate-box">
											<div class="room-wrap">
												<div class="row">
													<div class="col-md-6 col-sm-6">
														<div class="room-img" style="background-image: url(<?php echo e(asset('img/rooms_image/'.$image[$key]->image )); ?>);"></div>
													</div>
													<div class="col-md-6 col-sm-6">
														<div class="desc">
															<h2><?php echo e($rooms->type_room); ?></h2>
															<p class="price"><span><?php echo e($rooms->harga); ?></span> <small>/ night</small></p>
															<p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
															<p><a href="<?php echo e(route('cart.agent',$rooms->id)); ?>" class="btn btn-primary">Book Now!</a></p>
														</div>
													</div>
												</div>
											</div>
										</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</div>
								</div>
							</div>
						</div>
					</div>

					<!-- SIDEBAR-->
					
				</div>
			</div>
		</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('homepage.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\trainer\Downloads\travel-master\Modules\Agent\Providers/../Resources/views/details_product.blade.php ENDPATH**/ ?>