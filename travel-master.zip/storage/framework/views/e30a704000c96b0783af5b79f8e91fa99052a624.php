<?php $__env->startSection('content'); ?>
<div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Master Agent</strong>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Nama</th>
                                            <th>Company</th>
                                            <th>Alamat</th>
                                            <th>Email</th>
                                            <th>action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $hoteliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($hotel->name); ?></td>
                                            <td><?php echo e($hotel->company); ?></td>
                                            <td><?php echo e($hotel->alamat); ?></td>
                                            <td><?php echo e($hotel->email); ?></td>
                                            <td><button onclick="window.location.href='/confirmasiagent/hotelier/<?php echo e($hotel->id_hoteliers); ?>'" class="btn btn-success">Konfimasi</button>
</td>
                                        </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\trainer\Downloads\travel-master\Modules\ConfirmasiAgent\Providers/../Resources/views/hotelier.blade.php ENDPATH**/ ?>