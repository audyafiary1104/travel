<?php $__env->startSection('content'); ?>
<div class="animated fadeIn">
    <div class="row">

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Confimasi Agent</strong>
                </div>
                <div class="card-body">
                    <table id="bootstrap-data-table" class="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Nama User</th>
                                <th>Company</th>
                                <th>Alamat</th>
                                <th>Alamat Email</th>
                                <th>action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php $__currentLoopData = $agent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($agent->name); ?></td>
                                <td><?php echo e($agent->company); ?></td>
                                <td><?php echo e($agent->alamat); ?></td>
                                <td><?php echo e($agent->email); ?></td>
                                <td><button onclick="window.location.href='/confirmasiagent/agent/<?php echo e($agent->id_agent); ?>'" class="btn btn-success">Konfimasi</button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\trainer\Downloads\travel-master\Modules\ConfirmasiAgent\Providers/../Resources/views/index.blade.php ENDPATH**/ ?>