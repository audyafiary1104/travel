<!-- Left Panel -->
<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">

                <li class="menu-title"></li><!-- /.menu-title -->
                <li>
                    <a href="<?php echo e(route('agent.dashboard')); ?>"> <i class="menu-icon ti-email"></i>Dashboard </a>
                </li>
               
                </li>


                <li class="menu-title">Reservation</li><!-- /.menu-title -->

                <li>
                    <a href="<?php echo e(route('agent.dashboard_booking')); ?>"> <i class="menu-icon ti-email"></i>My Booking</a>
                </li>

                </li>

            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside><?php /**PATH C:\Users\trainer\Downloads\travel-master\resources\views/agent_dashboard/resource/sidebar.blade.php ENDPATH**/ ?>