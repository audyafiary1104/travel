<?php

return [
    'name' => 'HolidaysSuplier'
];
