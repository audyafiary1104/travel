<?php

return [
    'name' => 'Hoteliers'
];
