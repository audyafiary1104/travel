<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ConfirmasiAgent\\Providers\\ConfirmasiAgentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ConfirmasiAgent\\Providers\\ConfirmasiAgentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);