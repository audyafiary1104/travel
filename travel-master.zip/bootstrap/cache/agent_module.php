<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Agent\\Providers\\AgentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Agent\\Providers\\AgentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);