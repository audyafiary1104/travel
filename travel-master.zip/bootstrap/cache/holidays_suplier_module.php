<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\HolidaysSuplier\\Providers\\HolidaysSuplierServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\HolidaysSuplier\\Providers\\HolidaysSuplierServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);