<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\AgentDashboard\\Providers\\AgentDashboardServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\AgentDashboard\\Providers\\AgentDashboardServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);