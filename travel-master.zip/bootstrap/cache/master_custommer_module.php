<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MasterCustommer\\Providers\\MasterCustommerServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MasterCustommer\\Providers\\MasterCustommerServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);