<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Hoteliers\\Providers\\HoteliersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Hoteliers\\Providers\\HoteliersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);