<?php
return [
  "driver" => "smtp",
  "host" => "smtp.mailtrap.io",
  "port" => 2525,
  "from" => array(
      "address" => "from@example.com",
      "name" => "Example"
  ),
  "username" => "b5c8ca4ffb4d58",
  "password" => "c9f2606dab3572",
  "sendmail" => "/usr/sbin/sendmail -bs"
];
